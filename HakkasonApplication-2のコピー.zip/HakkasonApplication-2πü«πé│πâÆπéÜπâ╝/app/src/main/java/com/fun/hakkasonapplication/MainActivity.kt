package com.`fun`.hakkasonapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //１）Viewの取得：メッセージを書く
        val btnwrite: Button = findViewById(R.id.btnWrite)

        //２）ボタンを押したらメッセージを書く画面へ
        btnwrite.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            startActivity(intent)
        }

        val btnread: Button = findViewById(R.id.btnRead)

        btnread.setOnClickListener {
            val intent = Intent(this, ThirdActivity::class.java)
            startActivity(intent)
        }

    }
}