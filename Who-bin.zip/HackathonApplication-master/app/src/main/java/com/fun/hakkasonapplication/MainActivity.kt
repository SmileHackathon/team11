package com.`fun`.hakkasonapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.`fun`.hakkasonapplication.databinding.ActivityMainBinding
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.URL
import java.util.Date
import java.util.Calendar
import java.text.SimpleDateFormat


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //天気の表示
        //必須
        getWeather()
        Thread.sleep(2000)

        //天気アイコンの表示
        val weatherIcon: ImageView = findViewById(R.id.weatherIcon)
        weatherIcon.setImageResource(resources.getIdentifier(weather, "drawable", packageName))
        //風向、風速の表示
        val weatherInfo: TextView = findViewById(R.id.Weathertext)
        weatherInfo.text =  windDeg + "　" + windSpeed

        val textclock = findViewById(R.id.textTimer) as TextView
        textclock.text =  getToday()

        //１）Viewの取得：メッセージを書く
        val btnread: ImageButton = findViewById(R.id.btnRead)
        val btnwrite: ImageButton = findViewById(R.id.btnWrite)
        val btnmemory: ImageButton = findViewById(R.id.btnMemory)

        //２）ボタンを押したらメッセージを書く画面へ
        btnwrite.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            startActivity(intent)
        }

        //val btnread: Button = findViewById(R.id.btnRead)

        btnread.setOnClickListener {
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)
        }

        btnmemory.setOnClickListener {
            val intent = Intent(this, ThirdActivity::class.java)
            startActivity(intent)
        }
    }

    @SuppressLint("SimpleDateFormat")
    fun getToday(): String {
        val date = Date()
        val format = SimpleDateFormat("MM/dd  HH:mm")
        return format.format(date)
    }

    private var resultText = ""
    private var placeLat = 41.7687 //緯度
    private var placeLon = 140.7288//経度
    private var weather = "" //天気アイコンのid
    private var windDeg = "" //風向
    private var windSpeed = "" //風速
    //天気情報の取得
    private fun getWeather(): Job = GlobalScope.launch {
        var API_KEY = "fb917168411ee4479ef479755b143630"
        var API_URL = "https://api.openweathermap.org/data/2.5/onecall?" +
                "lat=" + placeLat + "&" +
                "lon=" + placeLon + "&" +
                "lang=" + "ja" + "&" +
                "APPID=" + API_KEY
        var url = URL(API_URL)
        var br = BufferedReader(InputStreamReader(url.openStream()))
        var str = br.readText()
        var json = JSONObject(str)
        var current = json.getJSONArray("hourly")

        //天気アイコンを取得
        resultText = ""
        weather = "i" + current.getJSONObject(0).getJSONArray("weather").getJSONObject(0)
            .getString("icon")

        //風向を取得
        resultText = ""
        var wind_deg = ""
        wind_deg = current.getJSONObject(0).getString("wind_deg")
        var wd = ""
        var wind = wind_deg.toInt()
        var rd = 360
        if(wind < 1*rd/32 || wind >= 31*rd/32) {
            wd = "北"
        }else if(wind < 3*rd/32) {
            wd = "北北東"
        }else if(wind < 5*rd/32) {
            wd = "北東"
        }else if(wind < 7*rd/32) {
            wd = "東北東"
        }else if(wind < 9*rd/32) {
            wd = "東"
        }else if(wind < 11*rd/32) {
            wd = "東南東"
        }else if(wind < 13*rd/32) {
            wd = "南東"
        }else if(wind < 15*rd/32) {
            wd = "南南東"
        }else if(wind < 17*rd/32) {
            wd = "南"
        }else if(wind < 19*rd/32) {
            wd = "南南西"
        }else if(wind < 21*rd/32) {
            wd = "南西"
        }else if(wind < 23*rd/32) {
            wd = "西南西"
        }else if(wind < 25*rd/32) {
            wd = "西"
        }else if(wind < 27*rd/32) {
            wd = "西北西"
        }else if(wind < 29*rd/32) {
            wd = "北西"
        }else if(wind < 31*rd/32) {
            wd = "北北西"
        }
        windDeg = wd

        //風速を取得
        resultText = ""
        windSpeed = current.getJSONObject(0).getString("wind_speed") + "m/s"
    }
}