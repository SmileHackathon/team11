package com.`fun`.hakkasonapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import java.util.*
import android.widget.ImageButton

class Third02Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third02)

        val btnbackmain02 : ImageButton = findViewById(R.id.btnBackmain02)
        val btnBackmemory01: ImageButton = findViewById(R.id.btnBack02)

        btnBackmemory01.setOnClickListener {
            finish()
        }

        btnbackmain02.setOnClickListener {
            val intent = Intent(this@Third02Activity, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(intent)
        }
    }
}