package com.`fun`.hakkasonapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.content.Intent
import java.util.*
import android.widget.ImageButton


class Second02Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second02)

        val btnbackmain11 : ImageButton = findViewById(R.id.btnBackMain11)
        val btnBackwrite02: Button = findViewById(R.id.btnBack01)




        btnbackmain11.setOnClickListener {
            val intent = Intent(this@Second02Activity, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(intent)
        }

        //３）戻るボタン（アクティビティの終了）
        btnBackwrite02.setOnClickListener {
            finish()
        }

    }

}
