package com.`fun`.hakkasonapplication


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

class LoadingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loading)
        //ハンドラのメソッド呼び出す
        loadingDelay()
    }

    //画面の遷移を遅延するためのメソッド
    fun loadingDelay(){
        //ハンドラを生成し、遅延時間を2秒に設定
        Handler().postDelayed({
            //2秒以降に画面を遷移するためのIntent設定
            val nextIntent = Intent(this, MainActivity::class.java)
            startActivity(nextIntent)
        }, 1500)
    }
}