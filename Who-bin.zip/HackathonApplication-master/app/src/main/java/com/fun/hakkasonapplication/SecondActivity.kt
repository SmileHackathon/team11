package com.`fun`.hakkasonapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        val btnBack :ImageButton = findViewById(R.id.btnBack)
        val btnwrite02: ImageButton = findViewById(R.id.btnWrite02)

        btnwrite02.setOnClickListener {
            val intent = Intent(this, Second02Activity::class.java)
            startActivity(intent)
        }

        //３）戻るボタン（アクティビティの終了）
        btnBack.setOnClickListener{
            finish()
        }
    }
}