package com.`fun`.hakkasonapplication

interface Job {

}
